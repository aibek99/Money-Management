<script>
	import TransactionForm from '$lib/transaction_form.svelte';
</script>

<div id="form">
	<TransactionForm />
</div>

<style>
	#form {
		margin: 100px;
		display: flex;
		justify-content: center;
	}
</style>
