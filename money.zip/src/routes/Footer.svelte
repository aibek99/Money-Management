<footer class="footer-container">
  <div class="footer-left">
    <i class="fa-regular fa-copyright"></i>
    2023 Copyright
  </div>
  <div class="footer-right">
    Developed by MINI WORLDS team
  </div>
</footer>

<style>
  .footer-container {
      display: flex;
      flex-direction: row;
      position: relative;
      bottom: 0;
      background-color: black;
      color: white;
      display: flex;
      justify-content: space-between;
      align-items: center;
      font-family: 'Kanit', sans-serif;
      font-size: 12px;
      width: 100%;
  }

  .footer-left {
      padding: 20px;
  }

  .footer-right {
      padding: 20px;
  }
</style>