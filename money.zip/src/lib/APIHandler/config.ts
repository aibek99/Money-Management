
export const API_BASE_URL = 'https://shohjahonh.pythonanywhere.com/';

export const token: string = "0d37e69dcb762490e8588ae797ca162f8b6e31a4";
