import { writable } from 'svelte/store';

export const check = writable(false);
